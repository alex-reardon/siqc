from setuptools import setup, find_packages

setup(
    name='siqc',
    version='0.0.2',
    packages=find_packages(),
    author='Reardon, Fonville, Avants',
    author_email='areardon@invicro.com',
    description='siqc',
    url='https://github.com/alex-reardon/siqc',
)
